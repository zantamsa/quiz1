let questions = [
    {
        numb: 1,
        question: "Should phones be allowed in school?",
        answer: "C. Yes, but with phone-free zones",
        options: [
            "A. Maybe",
            "B. No",
            "C. Yes, but with phone-free zones",
            "D. I dont know"
        ]
    },
    {
        numb: 2,
        question: "What's the name of the podcast?",
        answer: "A. PhoneTalk",
        options: [
            "A. PhoneTalk",
            "B. PhonePodcast",
            "C. Podcast",
            "D. SmartphoneTalk"
        ]
    },
    {
        numb: 3,
        question: "What are the names of the people, talking in the podcast?",
        answer: "A. Pascal, Elvana",
        options: [
            "A. Pascal, Elvana",
            "B. Simon, Jessica",
            "C. Edon, Seba",
            "D. I dont know"
        ]
    },
    {
        numb: 4,
        question: "What is the podcast about?",
        answer: "D. Phones in school",
        options: [
            "A. I dont know",
            "B. Nothing",
            "C. Phones in general",
            "D. Phones in school"
        ]
    },
    {
        numb: 5,
        question: "How long does the podcast last? (guess question)",
        answer: "D. 4 minutes",
        options: [
            "A. 1 minute",
            "B. 8 minutes",
            "C. 2 minutes",
            "D. 4 minutes"
        ]
    }
];